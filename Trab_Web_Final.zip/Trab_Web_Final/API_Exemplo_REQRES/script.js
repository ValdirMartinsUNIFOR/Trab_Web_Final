customFetch('https://reqres.in/api/users', 'GET');
customFetch('https://reqres.in/api/users', 'POST', {name: 'POST data'});
customFetch('https://reqres.in/api/users/2', 'PUT', {name: 'PUT data'});
customFetch('https://reqres.in/api/users/2', 'DELETE');

function customFetch(url, type, data) {
    if(type === 'GET') {
        fetch(url, {
            method: type,
            headers: {
                'Content-type': 'aplication/json',
            },
        })
            .then((res) => {
                if(res.ok) {
                    console.log("Solicitação HTTP bem-sucedida");
                } else {
                    console.log("Solicitação HTTP mal-sucedida");
                }
                return res;
            })
            .then((res) => res.json())
            .then((data) => console.log(data))
            .catch((error) => console.log(error));
    }

    if(type === 'POST' || type === 'PUT') {
        fetch(url, {
            method: type,
            headers: {
                'Content-type': 'aplication/json',
            },
            boddy: JSON.stringify({data}),
        })
            .then((res) => {
                if(res.ok) {
                    console.log("Solicitação HTTP bem-sucedida");
                } else {
                    console.log("Solicitação HTTP mal-sucedida");
                }
                return res;
            })
            .then((res) => res.json())
            .then((data) => console.log(data))
            .catch((error) => console.log(error));
    }

    if(type === 'DELETE') {
        fetch(url, {
            method: type,
            headers: {
                'Content-type': 'apliication/json',
            },
        })
            .then((res) => {
                if(res.ok) {
                    console.log("Solicitação HTTP bem-sucedida");
                } else {
                    console.log("Solicitação HTTP mal-sucedida");
                }
                return res;
            })
            .catch((error) => console.log(error));
    }
}