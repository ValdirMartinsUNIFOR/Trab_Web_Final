var customers= {
    customer1: {
        fistName: "Valdir",
        lastName: "Martins",
        ative: true,
        age: 20,
        id: 1
    },

    customer2: {
        fistName: "Murilo",
        lastName: "Cravalho",
        ative: true,
        age: 22,
        id: 2
    },

    customer3: {
        fistName: "Angelo",
        lastName: "Ricardo",
        ative: false,
        age: 21,
        id: 3
    }
}

exports.findAll = function(req, res) {
    console.log("---> Encontrar Tudo: \n" + JSON.stringify(customers, null, 3))
    res.end("Todos os clientes: \n" + JSON.stringify(customers, null, 3))
}

exports.findOne = function(req, res) {
    var customer = customers["customer" + req.params.id]
    console.log("---> Encontre um cliente: \n" + JSON.stringify(customer, null, 5))
    res.end("Encontre um cliente: \n" + JSON.stringify(customer, null, 5))
}

exports.create = function(req, res) {
    var  newCustomer = req.body
    customers["customer" + newCustomer.id] = newCustomer
    console.log("---> Novo Cliente: \n" + JSON.stringify(newCustomer, null, 5))
    res.end("Novo Cliente: \n" + JSON.stringify(newCustomer, null, 5))
}

exports.update = function(req, res) {
    var id = parseInt(req.params.id)
    var updateCustomer = req.body
    if(customers["customer" + id] != null) {
        customers["customer" + id] = updateCustomer
        console.log("---> Atualizar com êxito, atualizar cliente: \n" + JSON.stringify(updateCustomer, null, 3))
        res.end("Atualizar com êxito: \n" + JSON.stringify(updateCustomer, null, 3))
    } else {
        res.end("Cliente Não Existe: \n" + JSON.stringify(updateCustomer, null, 3))
    }
}

exports.delete = function(req, res){
    var deleteCustomer = ["customer" + req.params.id]
    delete customers["customer" + req.params.id]
    console.log("---> Cliente excluído: \n" + JSON.stringify(deleteCustomer, null, 3))
    res.end("Cliente excluído: \n" + JSON.stringify(deleteCustomer, null, 3))
}