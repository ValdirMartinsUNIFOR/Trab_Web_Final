module.exports = function(app) {
    var  customers = require('../controllers/index')

    app.get('/api/customers', customers.findAll);
    app.get('/api/customers/:id', customers.findOne);
    app.post('/api/customers', customers.create);
    app.put('/api/customers/:id', customers.update);
    app.delete('/api/customers/:id', customers.delete);
}